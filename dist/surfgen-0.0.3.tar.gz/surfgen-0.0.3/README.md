# surfgen package - a useful tool for generating slab structures

This package is created for creating slab models in computational simulations of heterogeneous catalysis and electrocatalysis systems.

This package will need:
* ase
* pymatgen
* copy
