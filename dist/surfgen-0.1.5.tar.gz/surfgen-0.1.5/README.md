# surfgen
surfgen is a new way for creating surface slabs and find adsorption site automatically.

# how to install
```bash
pip install --upgrade surfgen
```

# Documentation
Please check https://surfgen.readthedocs.io/en/latest/

# possible collaborations
If you want to collaborate on this project, please send an email (z.he@fz-juelich.de) to me. I'll be happy to talk about it.
