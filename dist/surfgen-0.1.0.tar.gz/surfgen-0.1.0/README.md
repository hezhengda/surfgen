# surfgen
surfgen is a new way for creating surface slabs and find adsorption site automatically.
